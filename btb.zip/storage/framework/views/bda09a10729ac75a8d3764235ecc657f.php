

<?php $__env->startSection('title', 'Payment Gateways'); ?>

<?php $__env->startSection('content'); ?>
<h1>Manage Payment Gateways</h1>

<a href="<?php echo e(route('admin.payment-gateways.create')); ?>">Create New Gateway</a>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Wallet Address</th>
            <th>Logo</th>
            <th>QR Code</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($gateway->name); ?></td>
                <td><?php echo e($gateway->wallet_address); ?></td>
                <td>
                    <?php if($gateway->logo): ?>
                        <img src="<?php echo e(asset('storage/' . $gateway->logo)); ?>" alt="Logo" width="50">
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($gateway->qrcode): ?>
                        <img src="<?php echo e(asset('storage/' . $gateway->qrcode)); ?>" alt="QR Code" width="50">
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.payment-gateways.edit', $gateway->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('admin.payment-gateways.destroy', $gateway->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelproject\blacktoolbox\resources\views/admin/payment-gateways/index.blade.php ENDPATH**/ ?>