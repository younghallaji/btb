

<?php $__env->startSection('title', 'Create Email Template'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        
        <h4 class="py-3 breadcrumb-wrapper mb-4"><span class="text-muted fw-light">Gateway/</span> Payment Gateway</h4>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.payment-gateways.store')); ?>" method="POST" class="row" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="col-md-7 mb-3">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>

        <div class="col-md-7 mb-3">
            <label for="wallet_address">Wallet Address</label>
            <input type="text" id="wallet_address" name="wallet_address" class="form-control" value="<?php echo e(old('wallet_address')); ?>" required>
        </div>

        <div class="col-md-7 mb-3">
            <label for="description">Description</label>
            <textarea id="description" name="description" class="form-control"><?php echo e(old('description')); ?></textarea>
        </div>

        <div class="col-md-7 mb-3">
            <label for="logo">Logo</label>
            <input type="file" id="logo" name="logo" class="form-control" accept="image/*">
        </div> 

        <div class="col-md-7 mb-3">
            <label for="qrcode">QR Code</label>
            <input type="file" id="qrcode" name="qrcode" class="form-control" accept="image/*">
        </div>

        <div class="col-md-7 mb-3">
            <button type="submit" class="btn btn-primary">Create Payment Gateway</button>
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelproject\blacktoolbox\resources\views/admin/payment-gateways/create.blade.php ENDPATH**/ ?>