<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
            
        <h5 class="py-3 breadcrumb-wrapper mb-4">
            <span class="text-muted fw-light">Mails /</span> Mail Logs
        </h5>
            
        <?php if($mailLogs->count() > 0): ?>
        <div class="card p-3">
            <h5 class="card-header">Mail Logs</h5>
            <div class="card-datatable">
                <table class="dt-responsive table table-bordered">
                    <thead>
                        <tr>
                            <th>Recipient</th>
                            <th>Template</th>
                            <th>Coin</th>
                            <th>Quantity</th>
                            <th>Amount Charged</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mailLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($log->recipient_email); ?></td>
                                <td><?php echo e($log->template ? $log->template->name : 'N/A'); ?></td>
                                <td><?php echo e($log->coin); ?></td>
                                <td><?php echo e($log->quantity); ?></td>
                                <td><?php echo e($log->amount_charged); ?></td>
                                <td><?php echo e($log->created_at->format('M. j, Y g:i a')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    
            <!-- Pagination links -->
            <div class="d-flex justify-content-center">
                <?php echo e($mailLogs->links()); ?>

            </div>
        <?php else: ?>
            <p>No mail logs found.</p>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#view-template').on('click', function (e) {
            e.preventDefault();
            
            // Get the selected template ID
            var templateId = $('#template').val();

            // Make an AJAX request to get the template body
            $.ajax({
                url: '/email-template/' + templateId,
                method: 'GET',
                success: function (response) {
                    // Insert the template body into the modal
                    $('#template-body-content').html(response.body);
                },
                error: function () {
                    alert('Unable to load template. Please try again.');
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laravelproject\blacktoolbox\resources\views/mail/mail-logs.blade.php ENDPATH**/ ?>