

<?php $__env->startSection('title', 'Email Templates'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
            
        <div class="container mt-5">
            <h2 class="mb-4">Rejected Deposit History</h2>
    
            <?php if($deposits->isEmpty()): ?>
                <p>No deposit history found.</p>
            <?php else: ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Reference Number</th>
                            <th>Amount</th>
                            <th>Payment Gateway</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($deposit->ref_no); ?></td>
                                <td><?php echo e($deposit->amount); ?></td>
                                <td><?php echo e($deposit->paymentGateway->name); ?></td>
                                <td><?php echo e(ucfirst($deposit->status)); ?></td>
                                <td><?php echo e($deposit->created_at->format('d M, Y H:i')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.deposits.approve', $deposit->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button class="btn btn-success" type="submit">Approve</button>
                                    </form>
                                
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

    </div>
      <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelproject\blacktoolbox\resources\views/admin/deposits/rejected.blade.php ENDPATH**/ ?>