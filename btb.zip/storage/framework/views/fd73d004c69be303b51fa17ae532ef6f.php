<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mt-5 row">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="card col-md-7">
            <div class="card-header">
                <h4>Send Mail</h4>
                <span class="badge badge-pill badge-info">Account Balance: <?php echo e(number_format(Auth::user()->balance, 2)); ?></span>
            </div>

            <div class="card-body">
                <p>Mailing Fee: 5 BTB</p>
                <form action="<?php echo e(route('mail.send')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <label for="recipient_email">Recipient Email <i class="bx bx-info-circle"></i></label>
                        <input type="email" class="form-control" id="recipient_email" name="recipient_email" placeholder="Email to receive link" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="template">Select Template</label>
                        <select class="form-control" id="template" name="template_id" required>
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($template->id); ?>"><?php echo e($template->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a href="#" id="view-template" data-toggle="modal" data-target="#templateModal">View Template</a>
                    </div>

                    <div class="form-group mb-3">
                        <label for="coin">Select Coin</label>
                        <select class="form-control" id="coin" name="coin" required>
                            <option value="BTC">Bitcoin</option>
                            <option value="ETH">Ethereum</option>
                            
                        </select>
                    </div>

                    <div class="form-group mb-3">
                        <label for="quantity">Quantity <i class="bx bx-info-circle"></i></label>
                        <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="min_balance">Min Balance <i class="bx bx-info-circle"></i></label>
                        <input type="number" class="form-control" id="min_balance" name="min_balance" min="0" required>
                    </div>

                    <button type="submit" class="btn btn-success">Send Mail</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal to view template content -->
    <div class="modal fade" id="templateModal" tabindex="-1" role="dialog" aria-labelledby="templateModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="templateModalLabel">Template Preview</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div id="template-body-content">
              <!-- Template content will be loaded here -->
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#view-template').on('click', function (e) {
            e.preventDefault();
            
            // Get the selected template ID
            var templateId = $('#template').val();

            // Make an AJAX request to get the template body
            $.ajax({
                url: '/email-template/' + templateId,
                method: 'GET',
                success: function (response) {
                    // Insert the template body into the modal
                    $('#template-body-content').html(response.body);
                },
                error: function () {
                    alert('Unable to load template. Please try again.');
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laravelproject\blacktoolbox\resources\views/mail/single-mail.blade.php ENDPATH**/ ?>